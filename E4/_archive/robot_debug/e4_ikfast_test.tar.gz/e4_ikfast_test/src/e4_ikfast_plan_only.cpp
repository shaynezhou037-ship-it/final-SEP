#include <chrono>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <memory>
#include <thread>
#include <vector>

#include <Eigen/Geometry>
#include <geometry_msgs/msg/pose.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/robot_state/robot_state.h>
#include <rclcpp/rclcpp.hpp>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>

int main(int argc, char** argv)
{
  rclcpp::init(argc, argv);

  rclcpp::NodeOptions options;
  options.automatically_declare_parameters_from_overrides(true);
  auto node = rclcpp::Node::make_shared("e4_ikfast_plan_only", options);

  auto logger = node->get_logger();

  // Defaults = H1 high target converted from the local E4 T105 workspace
  // to MoveIt base_link->hand_tcp using the 20-point local offset:
  // d = URDF_FK - T105 ~= (-1.609, +0.047, +54.227) mm.
  const double x = node->get_parameter_or("x", 0.1326381252);
  const double y = node->get_parameter_or("y", 0.0745486082);
  const double z = node->get_parameter_or("z", -0.0251749190);

  // For this 5-DOF chain, firmware/URDF comparison showed:
  // MoveIt roll ~= firmware r, pitch ~= firmware tit, yaw ~= firmware b.
  const double roll  = node->get_parameter_or("roll", 0.0);
  const double pitch = node->get_parameter_or("pitch", 1.5);
  const double yaw   = node->get_parameter_or("yaw", 0.5120438303);

  // Spin in background because MoveGroupInterface needs ROS callbacks.
  rclcpp::executors::SingleThreadedExecutor executor;
  executor.add_node(node);
  std::thread spin_thread([&executor]() { executor.spin(); });

  try
  {
    moveit::planning_interface::MoveGroupInterface move_group(node, "hand");
    move_group.setPoseReferenceFrame("base_link");
    move_group.setEndEffectorLink("hand_tcp");
    move_group.setPlanningTime(5.0);
    move_group.setNumPlanningAttempts(5);

    geometry_msgs::msg::Pose target_pose;
    target_pose.position.x = x;
    target_pose.position.y = y;
    target_pose.position.z = z;

    tf2::Quaternion q;
    q.setRPY(roll, pitch, yaw);
    q.normalize();
    target_pose.orientation = tf2::toMsg(q);

    std::cout << std::fixed << std::setprecision(9);
    std::cout << "============================================================\n";
    std::cout << "E4 TRUE IKFAST TEST -- PLAN ONLY, NO EXECUTION\n";
    std::cout << "============================================================\n";
    std::cout << "group           = hand\n";
    std::cout << "reference frame = base_link\n";
    std::cout << "eef link        = hand_tcp\n";
    std::cout << "target xyz [m]  = "
              << x << ", " << y << ", " << z << "\n";
    std::cout << "target rpy [rad]= "
              << roll << ", " << pitch << ", " << yaw << "\n";

    // IMPORTANT:
    // This overload computes a single joint target from the Cartesian pose via
    // MoveIt's configured kinematics solver (IKFast in this workspace).
    bool ik_ok = move_group.setJointValueTarget(target_pose, "hand_tcp");

    std::cout << "\n[IK]\n";
    std::cout << "setJointValueTarget(Pose) = "
              << (ik_ok ? "SUCCESS" : "FAIL") << "\n";

    if (!ik_ok)
    {
      std::cout << "No exact IK solution. No planning or execution performed.\n";
      executor.cancel();
      spin_thread.join();
      rclcpp::shutdown();
      return 2;
    }

    std::vector<double> joint_target;
    move_group.getJointValueTarget(joint_target);
    const auto joint_names = move_group.getJointNames();

    std::cout << "\n[IK JOINT TARGET]\n";
    for (std::size_t i = 0; i < joint_target.size(); ++i)
    {
      const std::string name = i < joint_names.size() ? joint_names[i] : ("joint_" + std::to_string(i));
      std::cout << name << " = " << joint_target[i] << " rad\n";
    }

    auto state = move_group.getCurrentState(5.0);
    if (!state)
    {
      std::cout << "\n[ERROR] Could not obtain MoveIt RobotState.\n";
      executor.cancel();
      spin_thread.join();
      rclcpp::shutdown();
      return 3;
    }

    const auto* jmg = state->getJointModelGroup("hand");
    if (!jmg)
    {
      std::cout << "\n[ERROR] JointModelGroup 'hand' not found.\n";
      executor.cancel();
      spin_thread.join();
      rclcpp::shutdown();
      return 4;
    }

    state->setJointGroupPositions(jmg, joint_target);
    state->update();

    const Eigen::Isometry3d& fk = state->getGlobalLinkTransform("hand_tcp");
    const Eigen::Vector3d fk_p = fk.translation();

    Eigen::Quaterniond target_q(
      target_pose.orientation.w,
      target_pose.orientation.x,
      target_pose.orientation.y,
      target_pose.orientation.z);
    target_q.normalize();

    Eigen::Quaterniond fk_q(fk.rotation());
    fk_q.normalize();

    const double pos_err_m = (fk_p - Eigen::Vector3d(x, y, z)).norm();
    const double ori_err_rad = target_q.angularDistance(fk_q);

    std::cout << "\n[FK CHECK OF IK SOLUTION]\n";
    std::cout << "FK xyz [m]      = "
              << fk_p.x() << ", " << fk_p.y() << ", " << fk_p.z() << "\n";
    std::cout << "position error   = " << pos_err_m * 1000.0 << " mm\n";
    std::cout << "orientation error= " << ori_err_rad << " rad\n";

    moveit::planning_interface::MoveGroupInterface::Plan plan;
    auto plan_code = move_group.plan(plan);
    const bool plan_ok =
      (plan_code == moveit::core::MoveItErrorCode::SUCCESS);

    std::cout << "\n[PLAN]\n";
    std::cout << "plan = " << (plan_ok ? "SUCCESS" : "FAIL") << "\n";

    if (plan_ok && !plan.trajectory_.joint_trajectory.points.empty())
    {
      const auto& last = plan.trajectory_.joint_trajectory.points.back();
      std::cout << "trajectory points = "
                << plan.trajectory_.joint_trajectory.points.size() << "\n";
      std::cout << "final planned joints [rad]:\n";
      for (std::size_t i = 0; i < last.positions.size(); ++i)
      {
        const auto& names = plan.trajectory_.joint_trajectory.joint_names;
        const std::string name = i < names.size() ? names[i] : ("joint_" + std::to_string(i));
        std::cout << "  " << name << " = " << last.positions[i] << "\n";
      }
    }

    std::cout << "\n[SAFETY]\n";
    std::cout << "NO execute() call exists in this program.\n";
    std::cout << "The physical robot should not move.\n";
    std::cout << "============================================================\n";
  }
  catch (const std::exception& e)
  {
    RCLCPP_ERROR(logger, "Exception: %s", e.what());
    executor.cancel();
    if (spin_thread.joinable()) spin_thread.join();
    rclcpp::shutdown();
    return 10;
  }

  executor.cancel();
  if (spin_thread.joinable()) spin_thread.join();
  rclcpp::shutdown();
  return 0;
}
